---
name: release-review
description: Find the two latest release/* branches, spin up a worktree for the newest one, run code-review-expert against it using the previous release as the diff base, and open the result in VS Code.
trigger: /release-review
---

# ⚠️ IMPORTANT FOR AGENTS

**No user prompts during normal runs.** Everything is automatic — branch detection, worktree setup, and review execution.

The only permitted stop conditions are:
- Fewer than two `release/*` branches exist (see Step 1).
- The worktree cannot be fast-forwarded and needs manual intervention.
- `code-review-expert` is not installed as a global skill.

The configurable worktree root is `C:/D/BD/W` by default. Override by passing a path as the first argument: `/release-review C:/my/worktrees`.

---

# release-review

Orchestrates a full code review of the latest release branch, diffed against the previous release branch.

---

## Execution Checklist

### Step 1 — Discover the two latest release branches

```bash
git fetch --prune --quiet
```

#### On non-Windows (bash/zsh):

```bash
git branch -r --sort=-committerdate \
  | grep -v HEAD \
  | grep '^\s*origin/release/' \
  | head -2
```

#### On Windows (PowerShell — use when `grep` is not on PATH):

```powershell
git branch -r --sort=-committerdate |
  Where-Object { $_ -notmatch 'HEAD' -and $_ -match 'origin/release/' } |
  Select-Object -First 2
```

**Detection:** try `Get-Command grep -ErrorAction SilentlyContinue`; if nothing is returned, use the PowerShell form.

Strip leading whitespace and the `origin/` prefix to get the short branch names.

- Result has **0 or 1 branches** → print:
  ```
  ⚠️  Fewer than two release/* branches found on the remote. Cannot determine a diff base.
      Found: <list or "none">
  ```
  and stop.

- Result has **2 or more branches** → take the first two (sorted newest first):
  - `CURRENT_RELEASE` = first entry (e.g. `release/2.14.0`)
  - BASE_RELEASE` = second entry (e.g. `release/2.13.0`)

Print:
```
Current release : <CURRENT_RELEASE>
Base release    : <BASE_RELEASE>
```

### Step 2 — Determine worktree path

If the user passed an argument to `/release-review`, use that as `WORKTREE_ROOT`.
Otherwise default to `C:/D/BD/W`.

Sanitize `CURRENT_RELEASE` for use as a directory name: replace `/`, `\`, `:`, `*`, `?`, `"`, `<`, `>`, `|` with `-`.

```
WORKTREE_PATH = <WORKTREE_ROOT>/<sanitized-current-release>
```

Example: `release/2.14.0` → `C:/D/BD/W/release-2.14.0`

### Step 3 — Create or reuse the worktree

#### If `WORKTREE_PATH` does not exist:

```bash
git worktree add "<WORKTREE_PATH>" "origin/<CURRENT_RELEASE>"
```

If this fails, print the git error and stop.

#### If `WORKTREE_PATH` already exists:

```bash
git fetch origin "<CURRENT_RELEASE>"
```

Then inside the worktree:

```bash
cd "<WORKTREE_PATH>"
git pull --ff-only
```

If `git pull --ff-only` fails (diverged history), print:
```
⚠️  Worktree at <WORKTREE_PATH> has diverged and cannot be fast-forwarded.
    Reset it manually or delete the worktree with:
    git worktree remove "<WORKTREE_PATH>" --force
```
and stop.

After creation or reuse, print:
```
Worktree ready: <WORKTREE_PATH>
```

### Step 4 — Run `code-review-expert` with BASE_RELEASE as the diff base

Change the working directory to `WORKTREE_PATH` and invoke the `code-review-expert` skill with these overrides:

- **Base branch**: `BASE_RELEASE` (e.g. `release/2.13.0`). This overrides `code-review-expert`'s normal develop/main/master detection — pass `BASE_RELEASE` directly as `BASE_BRANCH` so Step 1 of that skill is skipped.
- **Output file**: written to `<WORKTREE_PATH>/codereview-<sanitized-current-release>.md` (the skill writes to the cwd root automatically).
- **Suppress Step 11** (interactive fix checklist): after `code-review-expert` completes Steps 1–10, treat the selection as `none` automatically. Do not present the "Which items should I implement?" prompt.

If `code-review-expert` is not installed as a global skill, print:
```
code-review-expert skill not found. Install it first.
```
and stop.

Store the resulting path as:
```
REVIEW_FILE = <WORKTREE_PATH>/codereview-<sanitized-current-release>.md
```

### Step 5 — Open the review file

Try VS Code first:

```bash
code "<REVIEW_FILE>"
```

If `code` is not on PATH (command not found / non-zero exit):

**On Windows:**
```powershell
Start-Process "<REVIEW_FILE>"
```

**On macOS:**
```bash
open "<REVIEW_FILE>"
```

**On Linux:**
```bash
xdg-open "<REVIEW_FILE>"
```

### Step 6 — Print completion summary

Print exactly these four lines:

```
Current release : <CURRENT_RELEASE>
Base release    : <BASE_RELEASE>
Worktree        : <WORKTREE_PATH>
Review          : <REVIEW_FILE>
```

---

## Rules

- Never modify files in the original repo — all changes happen inside `WORKTREE_PATH`.
- Do not delete or prune worktrees automatically; leave cleanup to the user.
- Do not invent or guess a base branch if only one release branch exists — stop as described in Step 1.
- All `code-review-expert` rules (evidence requirement, `file:line` references, no vague findings) apply unchanged inside Step 4.
