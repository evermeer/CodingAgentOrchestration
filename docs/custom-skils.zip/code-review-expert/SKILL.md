---
name: code-review-expert
description: Expert code review comparing current branch to develop by default. Detects SOLID violations, security risks, and proposes actionable improvements.
trigger: /code-review-expert
---

# ⚠️ IMPORTANT FOR AGENTS

**NO USER PROMPTS during normal runs.** Gather all git context automatically. Only ask the user if none of `develop`, `main`, or `master` exist.

**Evidence rule:** Every finding MUST include a `file:line` reference and concrete evidence (code snippet, diff excerpt, or measurable metric). Vague or generic feedback ("this could be cleaner") is REJECTED and must not appear in the output file.

---

# code-review-expert

Performs a comprehensive code review by orchestrating multiple sub-skills and writing all actionable findings to a markdown file at the repo root.

---

## Execution Checklist

Follow these steps in order. Do not skip steps. Do not prompt the user unless step 1d applies.

### Step 1 — Detect base branch (automatic, no prompts)

```bash
# 1a. Get current branch
git rev-parse --abbrev-ref HEAD

# 1b. Try develop first
git show-ref --verify --quiet refs/heads/develop && echo "develop" || \
  git show-ref --verify --quiet refs/heads/main && echo "main" || \
  git show-ref --verify --quiet refs/heads/master && echo "master" || \
  echo "NONE"
```

- If result is `develop`, `main`, or `master` → use it as `BASE_BRANCH`. No prompt.
- **1d.** If result is `NONE` → ask the user: "No develop/main/master branch found. Which branch should I compare against?"

### Step 2 — Compute diff and changed files

```bash
# Compute merge-base to avoid including unrelated history
MERGE_BASE=$(git merge-base HEAD <BASE_BRANCH>)

# List changed files
git diff --name-only $MERGE_BASE HEAD

# Full diff (for sub-skills to consume)
git diff $MERGE_BASE HEAD
```

Save `CURRENT_BRANCH`, `BASE_BRANCH`, and `MERGE_BASE` for use in later steps.

### Step 3 — Sanitize branch name for output filename

Replace `/` and any character that is unsafe in a filename (`\ : * ? " < > |`) with `-`.

```
OUTPUT_FILE = "codereview-<sanitized-branch-name>.md"
```

Example: branch `feature/BSP-123_my-feature` → `codereview-feature-BSP-123_my-feature.md`

### Step 4 — Run sub-skill: `code-review`

Invoke the `code-review` skill (built-in) against the diff computed in Step 2.

- Pass `--fix` only if the user explicitly requested auto-fixes; otherwise run in read mode.
- Collect all findings (bugs, security, performance, architecture, SOLID violations).
- Focus areas:
  - **Bugs**: logic errors, null dereferences, race conditions, off-by-one errors
  - **Security**: injection, insecure deserialization, hardcoded secrets, missing auth checks, OWASP Top 10
  - **Performance**: N+1 queries, unbounded loops, unnecessary allocations, sync-over-async
  - **Architecture**: layer violations (Clean Architecture), coupling, cohesion
  - **SOLID violations**: SRP, OCP, LSP, ISP, DIP — name the violated principle explicitly

### Step 5 — Run sub-skill: `superpowers:requesting-code-review`

Invoke the `superpowers:requesting-code-review` skill to structure findings as a formal review request, enriching each finding with:
- Severity: `critical` / `major` / `minor` / `nit`
- Category: one of `bug`, `security`, `performance`, `architecture`, `solid`, `style`
- Suggested fix (concrete code or pattern, not vague advice)

### Step 6 — Run sub-skill: `karpathy-guidelines` (validation pass)

Apply Karpathy's four principles as a validation filter over the findings collected so far:

1. **Think Before Coding**: Are any findings based on wrong assumptions? Remove them.
2. **Simplicity First**: Are suggested fixes more complex than needed? Simplify.
3. **Surgical Changes**: Are findings calling for refactors beyond the diff scope? Downgrade to `nit` or remove.
4. **Goal-Driven Execution**: Does each finding have a clear, verifiable success criterion?

Discard findings that fail this filter.

### Step 7 — Run sub-skill: `evidence-validator` (audit pass)

Run the `evidence-validator` skill over the surviving findings. For each finding:

- Verify the `file:line` reference exists in the diff or the current HEAD.
- Verify the evidence (code snippet) matches what is actually in the file at that line.
- Reject any finding where the reference is stale, incorrect, or fabricated.

Only findings that pass evidence validation proceed to the output file.

### Step 8 — Write output file

Write all validated findings to `<repo-root>/<OUTPUT_FILE>`.

**Required file structure:**

```markdown
# Code Review: <CURRENT_BRANCH> → <BASE_BRANCH>

> Generated: <ISO-8601 timestamp>  
> Merge base: <MERGE_BASE (first 8 chars)>  
> Changed files: <count>

---

## Summary

| Severity | Count |
|---|---|
| critical | N |
| major | N |
| minor | N |
| nit | N |

---

## Findings

### [CRITICAL/MAJOR/MINOR/NIT] <Short title> — `<category>`

**File:** `path/to/file.cs:42`

**Evidence:**
```<lang>
<exact code snippet from the file at that line>
```

**Problem:** <one sentence, no waffling>

**Fix:** <concrete suggestion — code snippet or pattern>

---

(repeat for each finding)

## No issues found

(include this section only if zero findings passed all filters)
```

### Step 9 — Jira functional validation

#### 9a — Extract Jira issue key

Search for a Jira issue key in order of priority:

```bash
# 1. Current branch name
git rev-parse --abbrev-ref HEAD

# 2. Commit messages on the branch (since MERGE_BASE)
git log $MERGE_BASE..HEAD --format="%s %b"
```

Apply this regex to both outputs: `[A-Z][A-Z0-9]+-[0-9]+`  
Take the **first match** found. If multiple distinct keys appear, take all and process each.

- If **no key found** → append the "Functional Validation" section to the output file with status `⚠️ No Jira issue key detected — skipping functional validation.` and continue to Step 11.
- If **key(s) found** → proceed to 9b.

#### 9b — Fetch Jira issue details

Read `.jira.json` at the repo root to obtain `cloudId` and `siteUrl`. If the file does not exist, fall back to the project's CLAUDE.md / Agents.md for Jira configuration.

For each issue key found, call the Jira MCP tool `getJiraIssue` with the resolved `cloudId` and issue key. Extract:

| Field | Where to find it |
|---|---|
| Summary | `fields.summary` |
| Description | `fields.description` (Atlassian Document Format — extract plain text) |
| Acceptance Criteria | Look in description for sections named "Acceptance Criteria", "AC", "Definition of Done", or similar headings |
| Story Type | `fields.issuetype.name` |
| Status | `fields.status.name` |

If the MCP call fails (auth error, network, key not found) → append `⚠️ Could not fetch Jira issue <KEY>: <reason>` and continue to Step 11.

#### 9c — Extract requirements

Parse the description and acceptance criteria text into a structured list:

```
REQUIREMENTS = [
  { id: "AC-1", text: "<acceptance criterion or requirement sentence>" },
  ...
]
```

Rules:
- Split on numbered lists, bullet points, or explicit "AC-N" labels.
- Ignore boilerplate ("As a user…" preamble is context, not a criterion).
- Each requirement must be a testable statement ("the system SHALL / MUST / SHOULD…" or an observable outcome).
- If no structured criteria are found, treat the entire description as one requirement and note this in the output.

#### 9d — Validate code changes against requirements

For each requirement in `REQUIREMENTS`, determine its coverage status by examining:

1. **The diff** (from Step 2) — does any changed code path implement the stated behaviour?
2. **Test files** in the diff — do any test method names, assertions, or test descriptions reference the requirement?
3. **The review findings** (from Steps 4–7) — does any finding relate to this requirement?

Assign one of three statuses:

| Status | Meaning |
|---|---|
| ✅ Covered | Clear evidence in diff or tests that this requirement is addressed |
| ⚠️ Partial | Some evidence but gaps remain (e.g. happy path only, no error handling) |
| ❌ Not covered | No evidence in the diff that this requirement is touched |

Evidence rules apply here too: every status must cite a specific `file:line` or test name, or a note that the requirement is out of scope for this branch (e.g. "frontend only").

#### 9e — Append "Functional Validation" section to output file

Append this section **after** the existing Findings section in the output markdown:

```markdown
---

## Functional Validation

**Jira issue:** [<KEY>](<siteUrl>/browse/<KEY>) — <Summary>  
**Story type:** <issuetype>  
**Status at review time:** <status>

### Acceptance Criteria Coverage

| # | Requirement | Status | Evidence |
|---|---|---|---|
| AC-1 | <requirement text, max 120 chars> | ✅ / ⚠️ / ❌ | `path/to/file.cs:42` or "no evidence found" |
| AC-2 | … | … | … |

### Gaps

(List each ❌ or ⚠️ item with a short explanation of what is missing. If all criteria are ✅, write "None — all acceptance criteria appear to be addressed.")

### Notes

- If the Jira issue was not fetchable, explain why here.
- If acceptance criteria were absent from the ticket, note it.
- If some criteria are intentionally out of scope for this branch (e.g. frontend work), state that explicitly.
```

### Step 10 — Print the output path

After writing the file, print exactly one line to the user:

```
Code review written to: <absolute-path-to-output-file>
```

### Step 11 — Interactive improvement checklist

Parse the written output file and extract every finding into a numbered checklist. Present it to the user in this exact format — nothing else above or below it:

```
── Code Review Checklist ──────────────────────────────────────────
 1. [CRITICAL] <title> — path/to/file.cs:42
 2. [MAJOR]    <title> — path/to/file.cs:87
 3. [MINOR]    <title> — path/to/other.cs:12
 4. [NIT]      <title> — path/to/other.cs:55
───────────────────────────────────────────────────────────────────

Which items should I implement?
  • Enter numbers or ranges: 1 3 5-7
  • Type "all" to implement everything
  • Type "none" to skip implementation
```

Wait for the user's response. Then:

**Parse the selection:**
- `none` → print `No changes made.` and stop.
- `all` → treat as if every number was listed.
- Numbers / ranges (e.g. `1 3 5-7`) → expand to a sorted, deduplicated list of finding indices.
- Invalid input → ask once to clarify; if still invalid, print `Could not parse selection. No changes made.` and stop.

**Implement selected items one by one, in order:**

For each selected finding:
1. Print a status line before starting:
   ```
   [N/M] Implementing #<index>: <title> …
   ```
2. Apply the fix described in the finding's **Fix** section. Make the minimum surgical change required — do not touch adjacent code.
3. After applying, print a completion line:
   ```
   [N/M] ✓ Done — <file>:<line>
   ```
   Or if the fix cannot be applied automatically:
   ```
   [N/M] ✗ Skipped — <reason in one sentence>
   ```
4. Move to the next selected item. Do not ask for confirmation between items.

After all selected items are processed, print a final summary:

```
── Implementation complete ────────────────────────────────────────
  Implemented : <count>
  Skipped     : <count>
  Total       : <count>
───────────────────────────────────────────────────────────────────
```

**Implementation rules:**
- Apply fixes surgically (Karpathy principle 3: touch only what you must).
- Never implement a finding that was marked `nit` without explicit user selection by number.
- If a finding's fix conflicts with a previously implemented fix in the same session, print `✗ Skipped — conflicts with #<earlier-index>` and move on.
- Do not re-run tests or builds automatically; leave that to the user.

---

## Rules

- **No findings without `file:line`** — every finding must reference a real location.
- **No vague language** — "consider", "might", "could be improved" without specifics → rejected.
- **Scope = the diff only** — do not review files untouched by the branch.
- **Severity discipline**: `critical` = data loss / security breach possible; `major` = functional bug or significant risk; `minor` = correctness concern with low blast radius; `nit` = style or trivial cleanup.
- **SOLID findings must name the principle** and show the violation in the evidence snippet.
- **Security findings must reference the OWASP category** where applicable.
