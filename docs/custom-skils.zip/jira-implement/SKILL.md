---
name: jira-implement
description: "Implementing a Jira issue end-to-end: branch, worktree, code, tests, draft PR."
trigger: /jira-implement
user-invocable: true
---

# ⚠️ IMPORTANT FOR AGENTS

**On any failure:** print the exact error text and a one-line proposed fix before retrying. Retry once. If it still fails, stop and report — do not silently swallow errors.

**Worktree isolation:** all implementation work happens inside the worktree. Never modify files in the original repo checkout.

**Jira config:** read `.jira.json` at the repo root for `cloudId`, `siteUrl`, `projectKey`. Fall back to CLAUDE.md / Agents.md. Never hardcode these values.

**My identity:** the logged-in Jira user is determined via `atlassianUserInfo` — call it once and cache the `accountId`.

**Configurable worktree root:** default is `C:/D/BD/W`. Override by passing a path as the first argument: `/jira-implement C:/other/root`. Construct paths with forward-slash joins; let the OS resolve.

---

# jira-implement

Implements a Jira user story end-to-end: creates a branch + worktree, writes code and tests guided by TDD and Karpathy principles, self-reviews with `code-review-expert`, and opens a draft PR.

---

## Execution Checklist

### Step 1 — Select a story

#### 1a — Story key or text supplied in the prompt

If the user's invocation includes a Jira issue key (regex `[A-Z][A-Z0-9]+-[0-9]+`) or story text, use that. Skip to Step 2.

#### 1b — No story supplied: fetch active-sprint To Do stories

Read `.jira.json` for `cloudId` and `projectKey`.

Call `atlassianUserInfo` to get the current user's `accountId`. Cache as `MY_ACCOUNT_ID`.

Call `searchJiraIssuesUsingJql` with:

```
project = <projectKey>
  AND issuetype in (Story, "User Story", Task, Bug)
  AND sprint in openSprints()
  AND status = "To Do"
  AND (assignee is EMPTY OR assignee = currentUser())
ORDER BY priority DESC, updated DESC
```

Retrieve up to **8 issues**. For each extract: key, summary, priority, assignee (name or "Unassigned"), story points.

If 0 results:
```
No "To Do" stories found in the active sprint for project <projectKey> that are unassigned or assigned to you.
```
Stop.

Present a numbered menu:

```
── Active sprint — To Do ───────────────────────────────────────────
 1. BSP-1234  [5 pts]  [Unassigned]    Short summary text here
 2. BSP-1235  [3 pts]  [You]           Another story summary
 …
────────────────────────────────────────────────────────────────────

Which story should I implement? Enter a number (1–N):
```

Validate. Ask once on invalid input; if still invalid: `Invalid selection. Aborting.`

Store selected key as `ISSUE_KEY`.

---

### Step 2 — Fetch full story details

Call `getJiraIssue` with `cloudId` and `ISSUE_KEY`.

Extract:
| Field | Path |
|---|---|
| Summary | `fields.summary` |
| Description | `fields.description` (ADF → plain text) |
| Acceptance Criteria | Section in description headed "Acceptance Criteria", "AC", "Acceptatiecriteria", or a numbered/bulleted list |
| Issue type | `fields.issuetype.name` |
| Priority | `fields.priority.name` |
| Labels | `fields.labels` |
| Linked issues | `fields.issuelinks` |
| Existing comments | `fields.comment.comments` (last 3, for context) |

On API failure: print exact response + proposed fix, retry once.

---

### Step 3 — Derive branch name and worktree path

#### Branch name

Slugify the summary:
1. Lower-case.
2. Replace any non-alphanumeric character with `-`.
3. Collapse consecutive `-` into one.
4. Trim leading/trailing `-`.
5. Truncate to 50 characters at a word boundary.

```
BRANCH_NAME = feature/<ISSUE_KEY>-<slugified-summary>
```

Examples:
- `BSP-123` + `"Add patient search to portal"` → `feature/BSP-123-add-patient-search-to-portal`
- `BSP-456` + `"Fix: null ref in ConversationCommandService"` → `feature/BSP-456-fix-null-ref-in-conversationcommandservice`

For Bug issue types, use `fix/` prefix instead of `feature/`.

#### Worktree path

Take `WORKTREE_ROOT` from the first argument to the skill, or default to `C:/D/BD/W`.

Sanitize `BRANCH_NAME` for filesystem: replace `/` with `-`.

```
WORKTREE_PATH = <WORKTREE_ROOT>/<sanitized-branch>
```

Example: `C:/D/BD/W/feature-BSP-123-add-patient-search-to-portal`

---

### Step 4 — Create the branch and worktree

```bash
git fetch --prune --quiet

# Create a new branch from the default base (develop → main → master)
BASE_BRANCH=$(
  git show-ref --verify --quiet refs/remotes/origin/develop && echo "origin/develop" ||
  git show-ref --verify --quiet refs/remotes/origin/main   && echo "origin/main"    ||
  echo "origin/master"
)

git worktree add -b "<BRANCH_NAME>" "<WORKTREE_PATH>" "$BASE_BRANCH"
```

On failure (e.g. branch already exists):
```
⚠️  git worktree add failed: <exact error>
Proposed fix: the branch <BRANCH_NAME> may already exist. Trying with existing branch…
```
Retry: `git worktree add "<WORKTREE_PATH>" "<BRANCH_NAME>"` (without `-b`). If the worktree path already exists and is usable, reuse it.

Print:
```
Branch    : <BRANCH_NAME>
Worktree  : <WORKTREE_PATH>
Base      : <BASE_BRANCH>
```

---

### Step 5 — Understand the codebase before writing code

Change the working directory to `WORKTREE_PATH`.

Read the repo's `Agents.md` and `CLAUDE.md` for architectural conventions. Then:

1. Identify which application(s) the story touches based on the summary and description.
2. Locate relevant existing files (handlers, services, repositories, tests) by searching inside `WORKTREE_PATH`.
3. Note the test framework (`xUnit` + `Shouldly` + `NSubstitute` + `Bogus` for modern apps).
4. Note the naming convention for tests: `MethodName_InputCondition_ExpectedResult`.
5. Note solution file(s) to build and test.

Invoke the `superpowers:karpathy-guidelines` skill now. Apply its four principles throughout Steps 6–7:
- **Think Before Coding**: state assumptions before writing a line.
- **Simplicity First**: minimum code that satisfies the AC — nothing speculative.
- **Surgical Changes**: touch only files directly related to the story.
- **Goal-Driven Execution**: define verifiable success criteria from the AC before coding.

---

### Step 6 — Implement using Test-Driven Development

Invoke the `superpowers:test-driven-development` skill and follow its cycle throughout implementation.

**TDD cycle per acceptance criterion:**

1. **Red** — write a failing test that encodes the acceptance criterion.
   - Test name: `MethodName_<condition>_<expected-result>`
   - For unit tests: mock all external dependencies with NSubstitute.
   - For integration tests: use TestContainers (only when the story requires DB/infra interaction).

2. **Green** — write the minimum production code to make the test pass. No gold-plating.

3. **Refactor** — clean up while keeping tests green. Apply SOLID:
   - **SRP**: one reason to change per class.
   - **OCP**: extend via abstractions, don't modify stable code.
   - **LSP**: subtypes must honour the base contract.
   - **ISP**: don't force callers to depend on methods they don't use.
   - **DIP**: depend on abstractions; inject via constructor.

4. Repeat for the next criterion.

**Quality checklist per change:**
- [ ] No hardcoded secrets or connection strings.
- [ ] No synchronous blocking over async (`.Result`, `.Wait()`).
- [ ] No N+1 query patterns.
- [ ] Error responses follow RFC 7807 (Problem Details).
- [ ] Dates use ISO 8601.
- [ ] New public API endpoints are documented (XML doc comments or OpenAPI attributes).

After each Red→Green→Refactor cycle, run:

```bash
dotnet build <solution-file> --no-restore /p:Configuration=Release
dotnet test  <solution-file> --no-build   --collect "Code coverage"
```

If the build or tests fail:
1. Print the exact failure output.
2. Diagnose and fix.
3. Re-run until green before moving to the next criterion.

---

### Step 7 — Self-review with `evidence-validator`

Invoke the `superpowers:evidence-validator` skill over the changes you made.

For each claim in your implementation (e.g. "this satisfies AC-3"):
- Provide a `file:line` reference.
- Provide a test name that verifies it.
- Reject any claim without concrete evidence.

Fix any gaps identified.

---

### Step 8 — Final build, test, and code review

Run the full build and test suite one final time:

```bash
dotnet build <solution-file> --no-restore /p:Configuration=Release
dotnet test  <solution-file> --collect "Code coverage"
```

All tests must be green before proceeding.

Then invoke the `code-review-expert` skill (cwd = `WORKTREE_PATH`) with:
- Base branch = `BASE_BRANCH` (not develop default detection — pass it directly).
- **Suppress Step 11** (interactive fix checklist): automatically fix all `critical` and `major` findings. Print each fix as:
  ```
  [auto-fix] #N <title> — <file>:<line>
  ```
  Leave `minor` and `nit` findings in the review file for human review. Do not fix them automatically.

After auto-fixes, re-run build + tests to confirm they remain green.

---

### Step 9 — Commit

Stage all changed files in the worktree (do not use `git add -A` blindly — list them explicitly or use `git add -u` to stage only tracked changes):

```bash
cd "<WORKTREE_PATH>"
git add -u
# Add any new files explicitly:
git add <new-files>
```

Commit with a message that follows the repo's conventional commit style:

```
<type>(<scope>): <ISSUE_KEY> <short imperative summary>

- <bullet: what changed and why>
- <bullet: test coverage added>

Refs: <ISSUE_KEY>
```

Types: `feat`, `fix`, `refactor`, `test`, `chore`.
Scope: the application or layer affected (e.g. `accountapi`, `luscii`, `core`).

---

### Step 10 — Push branch

```bash
git push --set-upstream origin "<BRANCH_NAME>"
```

On failure:
1. Print exact error.
2. Proposed fix (e.g. "Remote branch may already exist — try `git push --force-with-lease`").
3. Retry once with the proposed fix. Do NOT force-push without noting it explicitly to the user.

---

### Step 11 — Open a draft pull request

Use `gh pr create` (GitHub CLI) or the Azure DevOps repo MCP tool `repo_create_pull_request`, depending on which remote is configured.

#### Detect remote type

```bash
git remote get-url origin
```

- URL contains `github.com` → use `gh pr create`.
- URL contains `dev.azure.com` or `visualstudio.com` → use `mcp__azure-devops__repo_create_pull_request`.
- URL contains `bitbucket.org` → use `gh pr create` with Bitbucket target (or print manual instructions if CLI not available).

#### PR content

**Title:**
```
<ISSUE_KEY>: <original Jira summary> (Draft)
```

**Body:**
```markdown
## Summary

Implements <ISSUE_KEY>: <Jira summary>

Jira: <siteUrl>/browse/<ISSUE_KEY>

## Changes

- <bullet: key change 1>
- <bullet: key change 2>

## Test coverage

- <bullet: test class / method added>

## Acceptance criteria

| # | Criterion | Status |
|---|---|---|
| AC-1 | <text> | ✅ Covered — `file:line` |
| AC-2 | <text> | ✅ Covered — `file:line` |

## Notes

<Any open questions or follow-up items from the review file>

---
🤖 Implemented with [Claude Code](https://claude.com/claude-code) via `/jira-implement`
```

Create the PR as **draft**.

On failure: print exact error + proposed fix, retry once.

---

### Step 12 — Transition Jira issue (optional)

Call `transitionJiraIssue` to move `ISSUE_KEY` to "In Progress" (or the equivalent status in the project's workflow).

First call `getTransitionsForJiraIssue` to find the correct transition ID. Do not guess the ID.

If the transition fails: print the error, do not abort — the PR is already open.

---

### Step 13 — Print completion summary

Print exactly:

```
Branch   : <BRANCH_NAME>
Worktree : <WORKTREE_PATH>
PR       : <PR URL>
Jira     : <siteUrl>/browse/<ISSUE_KEY>
Review   : <WORKTREE_PATH>/codereview-<sanitized-branch>.md
```

---

## Rules

- **Never modify the original repo checkout** — all work stays in `WORKTREE_PATH`.
- **TDD is not optional** — tests come before production code, always.
- **No speculative code** — implement exactly what the acceptance criteria require.
- **Auto-fix only critical/major** review findings — leave minor/nit for human review.
- **Do not force-push without warning** the user explicitly.
- **Do not estimate story points** — that is the team's responsibility.
- **Jira config from `.jira.json`** — never hardcoded.
- **On any error**: exact output + proposed fix + one retry, then stop and report.
