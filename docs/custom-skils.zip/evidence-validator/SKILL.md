---
name: evidence-validator
description: Audits code reviews to eliminate AI slop by verifying every claim has concrete evidence (test outputs, file references, command results) - use after requesting-code-review to enforce fact-based feedback
---

# Evidence Validator

## Overview

Every claim in a code review must be grounded in observable fact. Opinions, vague impressions, and unverified assertions are not feedback — they are noise.

## What Counts as Evidence

| Evidence type | Acceptable form |
|---|---|
| File reference | `src/Foo.cs:42` — exact file and line |
| Diff hunk | Quoted `+`/`-` lines from the actual diff |
| Test output | Pasted `dotnet test` / `jest` / `pytest` output with pass/fail counts |
| Command result | Terminal output of a command you ran |
| Compiler/linter output | Exact error or warning text with location |

## What Is NOT Evidence

- "looks good" / "seems fine" / "should work"
- "probably correct" / "likely safe" / "might cause issues"
- "could be cleaner" / "this is a bit messy"
- "I think this handles it" / "you might want to consider"
- Paraphrases of code without quoting it
- Assertions about behavior that weren't tested

## Validation Process

For every claim in the review:

1. **Identify the claim** — what is being asserted?
2. **Find the evidence** — is there a file:line, output, or diff hunk backing it?
3. **Pass or fail:**
   - Pass → claim has concrete, verifiable evidence
   - Fail → mark the claim with `[NO EVIDENCE]` and the reason it fails

4. **After scanning all claims**, produce a verdict:

```
EVIDENCE AUDIT RESULT
─────────────────────
Passed: N claims
Failed: M claims

[NO EVIDENCE] "<quote of unsupported claim>"
  → Reason: opinion / vague / untested assertion
  → Fix: add file:line reference, or drop this claim

[NO EVIDENCE] ...
```

If all claims pass: `✓ All claims have concrete evidence.`

## Rules

**One strike per unsupported claim.** Do not soften or hedge the failure — if there is no evidence, it fails.

**Do not infer evidence.** If a reviewer says "this method is slow" without a benchmark or profiler output, it fails. You cannot invent the evidence they should have provided.

**Positive claims need evidence too.** "This looks correct" without a test run is as weak as "this looks wrong" without a line reference.

**Drop or prove.** Every failed claim must either be backed with evidence or removed from the review. There is no third option.

## Common Slop Patterns

| Slop phrase | Why it fails |
|---|---|
| "This should work" | Should is not does. Show a passing test. |
| "Looks good to me" | Looking is not verifying. Quote the code and reference the spec. |
| "Could cause a race condition" | Speculation. Show the interleaving or a failing concurrency test. |
| "This is cleaner" | Aesthetic opinion. Not actionable without a specific before/after. |
| "Probably handles the edge case" | Probably is not evidence. Show the test case. |
| "I think this is correct" | Thinking is not running. Show the output. |
