---
name: branch-review
description: Pick a remote branch from a numbered menu, spin up a git worktree for it, run code-review-expert against that worktree, and open the resulting review file in VS Code.
trigger: /branch-review
---

# ⚠️ IMPORTANT FOR AGENTS

**This skill drives an interactive branch picker, then delegates to `code-review-expert`.**

- Steps 1–3 require user input (branch selection). All other steps are automatic.
- The working directory for Steps 4–5 is the **worktree path**, not the original repo root.
- The interactive "which items to fix" step (Step 11 of `code-review-expert`) is **suppressed** — see Step 5 below.
- The configurable worktree root is `C:/D/BD/W/` by default. Override by passing a path as the first argument: `/branch-review C:/my/worktrees`.

---

# branch-review

Orchestrates a full code review of any remote branch without touching the working tree.

---

## Execution Checklist

### Step 1 — List candidate branches

#### On non-Windows (bash/zsh):

```bash
git fetch --prune --quiet

git branch -r --sort=-committerdate \
  | grep -v HEAD \
  | grep -v '^  origin/develop$' \
  | grep -v '^  origin/main$' \
  | grep -v '^  origin/master$' \
  | grep -v '^  origin/release/' \
  | head -8
```

#### On Windows (PowerShell — use when `grep` is not on PATH):

```powershell
git fetch --prune --quiet

git branch -r --sort=-committerdate |
  Where-Object {
    $_ -notmatch 'HEAD' -and
    $_ -notmatch '^\s*origin/develop$' -and
    $_ -notmatch '^\s*origin/main$' -and
    $_ -notmatch '^\s*origin/master$' -and
    $_ -notmatch '^\s*origin/release/'
  } |
  Select-Object -First 8
```

**Detection:** try `Get-Command grep -ErrorAction SilentlyContinue`; if it returns nothing, use the PowerShell form. Otherwise use bash.

Store the results as `CANDIDATES` (strip leading whitespace and the `origin/` prefix for display; keep the full `origin/<name>` ref for git commands).

If `CANDIDATES` is empty, print:
```
No candidate branches found. All remote branches may be protected or the repo has no remote.
```
and stop.

### Step 2 — Present numbered menu

Print the list to the user in this exact format:

```
── Recent branches ────────────────────────────────────────────────
 1. feature/BSP-123_my-feature        (last commit: 2 hours ago)
 2. feature/BSP-456_another           (last commit: 1 day ago)
 ...
───────────────────────────────────────────────────────────────────

Which branch should I review? Enter a number (1–8):
```

To get the "last commit" age for each candidate:

```bash
git log -1 --format="%cr" origin/<branch-name>
```

Wait for the user's response. Validate:
- Must be a single integer between 1 and the count of candidates.
- If invalid, ask once more. If still invalid, stop with: `Invalid selection. Aborting.`

Store the selected branch as `SELECTED_BRANCH` (e.g. `feature/BSP-123_my-feature`) and the full remote ref as `REMOTE_REF` (e.g. `origin/feature/BSP-123_my-feature`).

### Step 3 — Determine worktree root

If the user passed an argument to `/branch-review`, use that as `WORKTREE_ROOT`.  
Otherwise default to `C:/D/BD/W`.

Sanitize `SELECTED_BRANCH` for use as a directory name: replace `/`, `\`, `:`, `*`, `?`, `"`, `<`, `>`, `|` with `-`.

```
WORKTREE_PATH = <WORKTREE_ROOT>/<sanitized-branch-name>
```

Example: `feature/BSP-123_my-feature` → `C:/D/BD/W/feature-BSP-123_my-feature`

### Step 4 — Create or reuse the worktree

#### If `WORKTREE_PATH` does not exist:

```bash
git worktree add "<WORKTREE_PATH>" "<REMOTE_REF>"
```

If this fails (e.g. branch already tracked by another worktree), print the error and stop.

#### If `WORKTREE_PATH` already exists:

```bash
git fetch origin "<SELECTED_BRANCH>"

# Inside the worktree directory:
cd "<WORKTREE_PATH>"
git pull --ff-only
```

If `git pull --ff-only` fails (diverged history), print:
```
⚠️  Worktree at <WORKTREE_PATH> has diverged and cannot be fast-forwarded.
    Reset it manually or delete the worktree with:
    git worktree remove "<WORKTREE_PATH>" --force
```
and stop.

After creation or reuse, print:
```
Worktree ready: <WORKTREE_PATH>
```

### Step 5 — Run `code-review-expert` in the worktree

Change the working directory to `WORKTREE_PATH` and invoke the `code-review-expert` skill with these overrides:

- **Base branch**: use `develop` (or `main` / `master` as per `code-review-expert` Step 1 detection, run inside the worktree).
- **Output file**: written to `<WORKTREE_PATH>/codereview-<sanitized-branch-name>.md` (the skill already does this at the worktree root automatically).
- **Suppress Step 11** (interactive checklist): after `code-review-expert` completes Steps 1–10, do NOT present the "Which items should I implement?" prompt. Treat the selection as `none` automatically.

Store the resulting path as `REVIEW_FILE = <WORKTREE_PATH>/codereview-<sanitized-branch-name>.md`.

### Step 6 — Open the review file

Try VS Code first:

```bash
code "<REVIEW_FILE>"
```

If `code` is not on PATH (command not found / exit code non-zero):

**On Windows:**
```powershell
Start-Process "<REVIEW_FILE>"
```

**On macOS/Linux:**
```bash
open "<REVIEW_FILE>"          # macOS
xdg-open "<REVIEW_FILE>"      # Linux
```

### Step 7 — Print completion summary

Print exactly these two lines:

```
Worktree : <WORKTREE_PATH>
Review   : <REVIEW_FILE>
```

---

## Rules

- Never modify files in the original repo during this skill — all changes happen inside `WORKTREE_PATH`.
- Do not delete or prune worktrees automatically; leave cleanup to the user.
- If `code-review-expert` is not installed as a global skill, stop at Step 5 with: `code-review-expert skill not found. Install it first.`
- All `code-review-expert` rules (evidence requirement, no vague findings, file:line references) apply unchanged.
