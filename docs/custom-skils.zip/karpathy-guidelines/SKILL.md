---
name: karpathy-guidelines
description: Apply Andrej Karpathy's four coding principles — Think Before Coding, Simplicity First, Surgical Changes, Goal-Driven Execution — to any coding task. Invoke when starting a non-trivial implementation, reviewing a plan, or when the user types /karpathy-guidelines.
trigger: /karpathy-guidelines
---

# Karpathy Guidelines

Derived from Andrej Karpathy's observations on LLM coding pitfalls. Apply these four principles to every non-trivial coding task.

> "The models make wrong assumptions on your behalf and just run along with them without checking. They don't manage their confusion, don't seek clarifications, don't surface inconsistencies, don't present tradeoffs, don't push back when they should."
> — Andrej Karpathy

---

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them — don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

**Red flag:** You're about to pick an interpretation without telling the user.

---

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

**The test:** Would a senior engineer say this is overcomplicated? If yes, simplify.

---

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it — don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

**The test:** Every changed line should trace directly to the user's request.

---

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:

| Instead of... | Transform to... |
|---|---|
| "Add validation" | "Write tests for invalid inputs, then make them pass" |
| "Fix the bug" | "Write a test that reproduces it, then make it pass" |
| "Refactor X" | "Ensure tests pass before and after" |

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

---

## How to invoke this skill

When the user types `/karpathy-guidelines` or starts a non-trivial implementation task:

1. Read the task carefully.
2. State any assumptions or ambiguities you see before touching code.
3. If ambiguities exist, ask — don't guess.
4. Define the success criteria for the task.
5. Execute with surgical precision: minimum lines changed, no scope creep.
6. Verify against the stated success criteria before declaring done.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial one-liners, use judgment — not every change needs full rigor.

**These guidelines are working if:** fewer unnecessary changes in diffs, fewer rewrites due to overcomplication, and clarifying questions come before implementation rather than after mistakes.
