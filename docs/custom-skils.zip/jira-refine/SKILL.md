---
name: jira-refine
description: Refine a Jira user story with AI — restate, add assumptions, enrich with repo context, generate Given/When/Then scenarios, surface ambiguities, and append the result back to Jira under a clear AI header.
trigger: /jira-refine
user-invocable: true
---

# ⚠️ IMPORTANT FOR AGENTS

**Language rule:** All generated story content (restatement, assumptions, scenarios, questions) must be written in the **same language as the original Jira story**. Do not translate.

**Append-only rule:** When updating Jira, NEVER overwrite the original description. Always APPEND under the `**refined by AI:**` header.

**Confirmation gate:** After Step 3 (restatement + assumptions), you MUST wait for the user to confirm or correct before proceeding to Steps 4–7. Do not skip this gate.

**Jira config:** Read `.jira.json` at the repo root for `cloudId`, `siteUrl`, and `projectKey`. If the file does not exist, fall back to CLAUDE.md / Agents.md. Never hardcode these values.

**On any Jira API failure:** Print the exact error response, then print a one-line proposed fix (e.g. "Missing field X — retrying with field omitted"). Retry once. If it fails again, stop and report.

---

# jira-refine

Turns a rough Jira user story into a fully refined story with technical context, concrete test scenarios, and surfaced ambiguities — then appends the result back to Jira.

---

## Execution Checklist

### Step 1 — Select a story

#### 1a — User supplied a story key or text

If the user's invocation includes a Jira issue key (regex: `[A-Z][A-Z0-9]+-[0-9]+`) or story text, use that directly. Skip to Step 2.

Examples of direct invocations:
- `/jira-refine BSP-1234`
- `/jira-refine "As a practitioner I want to see my schedule"`

#### 1b — No story supplied: fetch unestimated future-sprint stories

Read `.jira.json` for `cloudId` and `projectKey`.

Call `searchJiraIssuesUsingJql` with this JQL:

```
project = <projectKey>
  AND issuetype in (Story, "User Story")
  AND sprint in futureSprints()
  AND "Story Points" is EMPTY
ORDER BY sprint ASC, updated DESC
```

Retrieve up to **8 issues**. For each, extract:
- Issue key
- Summary
- Sprint name
- Story points (expected: empty)

If 0 results are returned, try a second JQL broadening the search:

```
project = <projectKey>
  AND issuetype in (Story, "User Story")
  AND sprint not in openSprints()
  AND sprint in futureSprints()
ORDER BY updated DESC
```

If still 0 results, print:
```
No unestimated stories found in future sprints for project <projectKey>.
```
and stop.

Present the candidates as a numbered menu:

```
── Unrefined stories in future sprints ────────────────────────────
 1. BSP-1234  [Sprint 42]  As a practitioner I want to…
 2. BSP-1235  [Sprint 42]  As a patient I want to…
 …
───────────────────────────────────────────────────────────────────

Which story should I refine? Enter a number (1–N):
```

Wait for the user's response. Validate it is a number in range. Ask once on invalid input; if still invalid, stop with: `Invalid selection. Aborting.`

Store the selected issue key as `ISSUE_KEY`.

---

### Step 2 — Fetch full story details

Call `getJiraIssue` with the resolved `cloudId` and `ISSUE_KEY`.

Extract:
| Field | Path |
|---|---|
| Summary | `fields.summary` |
| Description | `fields.description` (Atlassian Document Format — convert to plain text) |
| Acceptance Criteria | Look for a section in the description titled "Acceptance Criteria", "AC", "Acceptatiecriteria", "Definition of Done", or a numbered/bulleted list after the user-story sentence |
| Story type | `fields.issuetype.name` |
| Reporter / Author | `fields.reporter.displayName` |
| Sprint | `fields.sprint.name` (or custom sprint field) |
| Story Points | `fields.story_points` or `fields.customfield_10016` |
| Labels | `fields.labels` |
| Linked issues | `fields.issuelinks` |

On API failure: print exact response + proposed fix, retry once.

---

### Step 3 — Restate and surface assumptions (CONFIRMATION GATE)

In the **language of the original story**, produce:

#### Restatement

Rewrite the story in your own words using this structure:

```
**Who:**   <the actor / persona>
**What:**  <the capability or action they want>
**Why:**   <the business or user value — "so that …">
```

Then write a single formatted user story sentence:

> As a **<who>**, I want **<what>**, so that **<why>**.

If the original story is already in correct format, still restate it to confirm your understanding.

#### Assumptions

List every assumption you are making — things that are implied but not stated. Number them:

```
Assumptions:
1. <assumption>
2. <assumption>
…
```

If no assumptions can be identified, write: `No assumptions — the story appears complete.`

#### Present to user

Print the restatement and assumptions, then ask:

```
Does this match your intent? Reply with:
  • "yes" or "ok" to continue
  • corrections or additions (free text) to update the restatement before I proceed
```

**Wait for the user's response.** If corrections are given, incorporate them and show the updated restatement once more before continuing. Do not proceed to Step 4 until the user explicitly confirms.

---

### Step 4 — Add technical context from the repository

Read the project's `Agents.md` (and `CLAUDE.md` if present) for architectural conventions, layer structure, naming rules, and tech stack.

Based on the confirmed story and repo context, add a **Technical Context** section:

```
**Technical Context:**
- Affected layer(s): <e.g. Application → Infrastructure → Presentation>
- Relevant service(s): <e.g. ConversationCommandService, AccountApi>
- Data store(s): <e.g. EF Core / SQL Server via WebspreekuurContext>
- API contract: <e.g. REST endpoint to add: POST /api/v1/conversations/{id}/messages>
- Auth requirements: <e.g. Practitioner role claim required>
- Async side-effects: <e.g. notification via Azure Service Bus + MassTransit>
- Constraints: <e.g. must follow RFC 7807 error responses, ISO 8601 dates>
```

Only include fields where you have evidence from the repo context or the story. Omit fields that are genuinely not applicable — do not speculate.

---

### Step 5 — Generate test scenarios (Given / When / Then)

#### 5a — Invoke `test-scenarios` skill if available

If the `test-scenarios` skill is installed, invoke it with the confirmed story text and acceptance criteria as input.

#### 5b — Fallback: generate scenarios inline

If `test-scenarios` is not installed, generate the scenarios directly.

For each acceptance criterion (and for each assumption that implies a testable behaviour), write one or more scenarios in this format:

```gherkin
Scenario: <short descriptive title>
  Given <precondition>
  When  <action>
  Then  <expected outcome>
```

Rules:
- Cover the **happy path** first.
- Add at least one **error / edge case** scenario per criterion.
- Use concrete values (not `<some value>`) where possible.
- Scenarios must be independently runnable — no shared state assumptions.
- Write in the same language as the story.

---

### Step 6 — Surface ambiguities

Review the full story, assumptions, technical context, and scenarios. For every point that is unclear, underspecified, or could be interpreted in more than one way, add a numbered question:

```
**Open questions:**
1. <question> — *e.g. Should the practitioner see all patients or only their own?*
2. <question>
…
```

If no ambiguities remain after refinement, write: `**Open questions:** None — the story appears fully specified.`

---

### Step 7 — Compose the refined block

Assemble the full refined content in the story's language:

```markdown
---

**refined by AI:**

**User story:**
As a <who>, I want <what>, so that <why>.

**Assumptions:**
1. …

**Technical Context:**
- Affected layer(s): …
- …

**Test scenarios:**

Scenario: <title>
  Given …
  When  …
  Then  …

Scenario: <error case>
  Given …
  When  …
  Then  …

**Open questions:**
1. …
```

---

### Step 8 — Preview and confirm before updating Jira

Show the user the full refined block and ask:

```
Ready to append this to BSP-XXXX in Jira.
Reply "yes" to update, "no" to discard, or paste corrections to adjust first.
```

Wait for the user's response:
- `no` → print `Update discarded. No changes made to Jira.` and stop.
- corrections → apply them to the block, show the updated version, ask again.
- `yes` / `ok` → proceed to Step 9.

---

### Step 9 — Append to Jira

Call `editJiraIssue` with the resolved `cloudId` and `ISSUE_KEY`.

Build the new description by **appending** the refined block to the existing description:

- If the description is in **Atlassian Document Format (ADF)**: append a horizontal rule node followed by the refined block as a new paragraph/text node sequence. Do not replace any existing nodes.
- If the description is **plain text / markdown**: append `\n\n---\n\n` followed by the refined markdown block.

On API failure:
1. Print the exact error response.
2. Print a proposed fix.
3. Retry once.
4. If still failing, print the full refined block as plain text so the user can paste it manually:
```
⚠️  Jira update failed. Paste this manually into the description:

<refined block>
```

On success, print:
```
✅  BSP-XXXX updated: <siteUrl>/browse/<ISSUE_KEY>
```

---

## Rules

- Never overwrite the original description — append only.
- Never translate — match the story's language throughout.
- The confirmation gate in Step 3 and the preview in Step 8 are mandatory; they cannot be skipped.
- Do not estimate story points — that is the team's responsibility.
- Do not assign the issue or change its status.
- Jira config always comes from `.jira.json` or CLAUDE.md / Agents.md; never hardcode `cloudId` or `projectKey`.
